"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Edit,
  Save,
  X,
  Check,
  Star,
  Users,
  DollarSign,
  Calendar,
  Clock,
  Target,
  Award,
  TrendingUp,
  TrendingDown,
  BookOpen,
  Mail,
  Phone,
  MapPin,
  Globe,
  Shield,
  BadgeCheck,
  Crown,
  Ban,
  UserCheck,
  UserX,
  RotateCcw,
  MessageSquare,
  Video,
  FileText,
  Download,
  Upload,
  Plus,
  Trash2,
  RefreshCw,
  Activity,
  AlertCircle,
  BarChart3,
  PieChart,
  Layers,
  Briefcase,
  GraduationCap,
  School,
  Heart,
  ThumbsUp,
  Eye,
  MoreVertical,
  ChevronDown,
  ExternalLink,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart as RechartsPie,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

// ─── MOCK TUTOR DATA ───────────────────────────────────────
function getMockTutor(id: string): any {
  const hourlyRate = 15000;
  return {
    id,
    name: "Dr. Adebayo Ola",
    avatar: "https://i.pravatar.cc/150?u=tutor1",
    coverImage: "https://picsum.photos/1200/300",
    title: "PhD Mathematics — 15+ years experience",
    email: "adebayo.ola@graviest.com",
    phone: "+2348012345678",
    gender: "male",
    dateOfBirth: "1975-03-15",

    specialization: ["mathematics", "physics"],
    subjects: ["Mathematics", "Physics", "Further Mathematics"],
    experience: 15,
    education: "PhD Mathematics, University of Ibadan",
    certifications: [
      "Certified Mathematics Educator",
      "WAEC Examiner Certification",
      "TRCN Certified",
    ],
    qualifications: ["STEM Curriculum Developer", "Assessment Specialist"],
    about:
      "Dr. Adebayo Ola is a renowned mathematics educator with over 15 years of experience helping students excel in JAMB, WAEC, and NECO examinations. His unique teaching methodology has helped over 1,000 students achieve distinctions in mathematics.",
    teachingStyle:
      "Interactive and student-centered approach with focus on practical problem-solving. Uses real-life examples to explain abstract concepts.",

    status: "active",
    verificationLevel: "verified",
    rating: 4.9,
    reviewCount: 847,
    totalStudents: 1250,
    totalSessions: 3420,
    completionRate: 98,
    responseTime: "< 1 hour",
    isOnline: true,
    isFeatured: true,
    isVerified: true,
    joinedDate: "2023-06-15",
    lastActive: "2025-03-20",

    hourlyRate,
    packages: [
      { name: "Single Session", duration: "1 hour", price: hourlyRate, savings: 0, sessions: 1 },
      {
        name: "5 Sessions Pack",
        duration: "5 hours",
        price: hourlyRate * 5 - Math.round(hourlyRate * 0.07),
        savings: Math.round(hourlyRate * 0.35),
        sessions: 5,
        popular: true,
      },
      {
        name: "10 Sessions Pack",
        duration: "10 hours",
        price: hourlyRate * 10 - Math.round(hourlyRate * 1.5),
        savings: Math.round(hourlyRate * 1.5),
        sessions: 10,
      },
      {
        name: "Monthly Plan",
        duration: "8 hrs/month",
        price: Math.round(hourlyRate * 8 * 0.8),
        savings: Math.round(hourlyRate * 8 * 0.2),
        sessions: 8,
      },
    ],

    availability: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    timeSlots: ["8:00 AM", "10:00 AM", "12:00 PM", "2:00 PM", "4:00 PM", "6:00 PM"],
    maxStudentsPerDay: 6,
    preferredSessionDuration: 60,

    languages: ["English", "Yoruba"],
    state: "Lagos",
    city: "Ikeja",
    teachingMode: "online",

    achievements: [
      "Best Mathematics Tutor Award 2023",
      "Helped 500+ students score A's in JAMB Mathematics",
      "Published author of 'Mathematics Made Simple'",
      "Featured in Educational Excellence Magazine",
    ],
    tags: ["JAMB Expert", "WAEC Specialist", "Quick Response", "Patient Teacher"],

    bankName: "GTBank",
    accountNumber: "0123456789",
    accountName: "Adebayo Ola",

    earnings: {
      totalEarnings: 4500000,
      thisMonth: 380000,
      lastMonth: 350000,
      pendingPayout: 304000,
      nextPayoutDate: "2025-04-15",
      commissionRate: 20,
      platformFees: 76000,
      netEarnings: 304000,
      monthlyBreakdown: Array.from({ length: 12 }, (_, i) => ({
        month: new Date(2024, i, 1).toLocaleString("default", { month: "short" }),
        earnings: Math.floor(Math.random() * 200000 + 250000),
        sessions: Math.floor(Math.random() * 30 + 25),
        students: Math.floor(Math.random() * 15 + 10),
      })),
      earningsBySubject: [
        { subject: "Mathematics", amount: 250000 },
        { subject: "Physics", amount: 100000 },
        { subject: "Further Maths", amount: 30000 },
      ],
    },

    recentSessions: Array.from({ length: 10 }, (_, i) => ({
      id: `sess_${i}`,
      studentName: [
        "Oluwaseun Adebayo",
        "Chioma Eze",
        "Emeka Nwachukwu",
        "Fatima Suleiman",
        "Tunde Bakare",
        "Ngozi Okonkwo",
        "Ibrahim Musa",
        "Aisha Bello",
        "David Okafor",
        "Grace Peters",
      ][i],
      studentEmail: `student${i}@email.com`,
      subject: i % 3 === 0 ? "Physics" : "Mathematics",
      date: new Date(Date.now() - i * 2 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      time: `${8 + Math.floor(Math.random() * 10)}:00 ${Math.random() > 0.5 ? "AM" : "PM"}`,
      duration: [30, 45, 60, 90][Math.floor(Math.random() * 4)],
      status: i < 7 ? "completed" : i < 9 ? "upcoming" : "cancelled",
      amount: hourlyRate,
      rating: i < 7 ? Math.floor(Math.random() * 2) + 4 : undefined,
      notes: i < 7 ? "Good progress on calculus topics." : undefined,
    })),

    recentReviews: Array.from({ length: 6 }, (_, i) => ({
      id: `rev_${i}`,
      studentName: ["Emmanuel O.", "Precious N.", "David A.", "Fatima M.", "Chidi O.", "Aisha B."][
        i
      ],
      studentAvatar: `https://i.pravatar.cc/40?u=stu${i}`,
      rating: 4 + Math.floor(Math.random() * 2),
      date: new Date(Date.now() - i * 5 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      comment: [
        "Dr. Adebayo is an exceptional tutor! He explained complex calculus concepts in a way I could easily understand.",
        "Very patient and knowledgeable. He doesn't move on until you truly understand the concept.",
        "Great tutor! His teaching style is very engaging. Highly recommended!",
        "The best mathematics teacher I've ever had. My JAMB score improved dramatically.",
        "Excellent at breaking down complex topics. Worth every naira!",
        "Professional, punctual, and incredibly effective teaching methods.",
      ][i],
      subject: i % 2 === 0 ? "Mathematics" : "Physics",
      sessionType: "One-on-One",
      helpful: Math.floor(Math.random() * 50) + 10,
      response: i < 2 ? "Thank you for the wonderful review! Keep practicing." : undefined,
      responseDate:
        i < 2
          ? new Date(Date.now() - i * 4 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
          : undefined,
    })),

    studentRetentionRate: 85,
    averageSessionRating: 4.8,
    repeatStudentRate: 72,
    cancellationRate: 3,

    cvUrl: "#",
    idCardUrl: "#",
    certificateUrls: ["#", "#", "#"],
    profileCompleted: 95,
  };
}

// ─── MAIN COMPONENT ────────────────────────────────────────
export default function AdminTutorDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [tutor, setTutor] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<
    "overview" | "sessions" | "reviews" | "earnings" | "documents"
  >("overview");
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<any>(null);
  const [showSuspendModal, setShowSuspendModal] = useState(false);

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      const data = getMockTutor(params.id as string);
      setTutor(data);
      setEditData(data);
      setLoading(false);
    }, 600);
  }, [params.id]);

  if (loading || !tutor) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-64 bg-gray-200 rounded" />
          <div className="h-48 bg-gray-200 rounded-2xl" />
          <div className="grid grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded-2xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    active: "bg-green-100 text-green-600",
    inactive: "bg-gray-100 text-gray-600",
    suspended: "bg-red-100 text-red-600",
    on_leave: "bg-blue-100 text-blue-600",
  };

  const handleSave = () => {
    setTutor(editData);
    setIsEditing(false);
  };

  const handleSuspend = () => {
    setTutor((prev: any) => ({ ...prev, status: "suspended" }));
    setShowSuspendModal(false);
  };

  const handleActivate = () => {
    setTutor((prev: any) => ({ ...prev, status: "active" }));
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          href="/admin/tutors"
          className="inline-flex items-center gap-2 text-[14px] text-text-muted hover:text-green-800 mb-4 transition-colors">
          <ArrowLeft size={16} /> Back to Tutors
        </Link>

        <div className="flex items-start justify-between">
          <div className="flex items-center gap-5">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl bg-cream flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
                {tutor.avatar ? (
                  <img src={tutor.avatar} alt="" className="w-full h-full object-cover" />
                ) : (
                  <Users size={36} className="text-green-800" />
                )}
              </div>
              {tutor.isOnline && (
                <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-green-500 border-3 border-white" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-3 mb-1">
                <h1 className="font-serif text-3xl text-green-900">{tutor.name}</h1>
                <span
                  className={`px-3 py-1 rounded-full text-[12px] font-semibold ${statusColors[tutor.status]}`}>
                  {tutor.status.replace("_", " ")}
                </span>
                {tutor.isVerified && (
                  <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-blue-100 text-blue-600 text-[12px] font-semibold">
                    <BadgeCheck size={14} /> Verified
                  </span>
                )}
                {tutor.isFeatured && (
                  <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-purple-100 text-purple-600 text-[12px] font-semibold">
                    <Crown size={14} /> Featured
                  </span>
                )}
              </div>
              <p className="text-text-muted">{tutor.title}</p>
              <div className="flex items-center gap-4 mt-2 text-[13px] text-text-muted">
                <span className="flex items-center gap-1">
                  <Star size={14} className="text-gold fill-gold" /> {tutor.rating} (
                  {tutor.reviewCount} reviews)
                </span>
                <span className="flex items-center gap-1">
                  <Users size={14} /> {tutor.totalStudents} students
                </span>
                <span className="flex items-center gap-1">
                  <Target size={14} /> {tutor.totalSessions} sessions
                </span>
                <span className="flex items-center gap-1">
                  <MapPin size={14} /> {tutor.city}, {tutor.state}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {tutor.status === "suspended" ? (
              <button
                onClick={handleActivate}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-green-800 text-white hover:bg-green-700 transition-all text-[14px] font-semibold">
                <UserCheck size={16} /> Reactivate
              </button>
            ) : (
              <button
                onClick={() => setShowSuspendModal(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-red-200 text-red-500 hover:bg-red-50 transition-all text-[14px] font-semibold">
                <Ban size={16} /> Suspend
              </button>
            )}

            {isEditing ? (
              <>
                <button
                  onClick={() => setIsEditing(false)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-gray-200 text-text-muted hover:bg-cream transition-all text-[14px] font-semibold">
                  <X size={16} /> Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="flex items-center gap-2 px-5 py-3 rounded-xl bg-green-800 text-white hover:bg-green-700 transition-all shadow-lg text-[14px] font-semibold">
                  <Save size={16} /> Save Changes
                </button>
              </>
            ) : (
              <button
                onClick={() => {
                  setIsEditing(true);
                  setEditData({ ...tutor });
                }}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-green-800 text-white hover:bg-green-700 transition-all shadow-lg text-[14px] font-semibold">
                <Edit size={16} /> Edit Profile
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {(
          [
            { key: "overview", label: "Overview", icon: Eye },
            { key: "sessions", label: "Sessions", icon: Calendar },
            { key: "reviews", label: "Reviews", icon: Star },
            { key: "earnings", label: "Earnings", icon: DollarSign },
            { key: "documents", label: "Documents", icon: FileText },
          ] as const
        ).map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`px-5 py-3 rounded-xl text-[14px] font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === key
                ? "bg-green-800 text-white shadow-lg"
                : "bg-white border border-gray-200 text-text-muted hover:bg-cream"
            }`}>
            <Icon size={16} /> {label}
          </button>
        ))}
      </div>

      {/* ─── OVERVIEW TAB ─── */}
      {activeTab === "overview" && (
        <div className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
            <QuickStat icon={Star} label="Rating" value={tutor.rating.toFixed(1)} color="#f59e0b" />
            <QuickStat
              icon={Users}
              label="Students"
              value={tutor.totalStudents.toLocaleString()}
              color="#3b82f6"
            />
            <QuickStat
              icon={Target}
              label="Sessions"
              value={tutor.totalSessions.toLocaleString()}
              color="#8b5cf6"
            />
            <QuickStat
              icon={Check}
              label="Completion"
              value={`${tutor.completionRate}%`}
              color="#10b981"
            />
            <QuickStat
              icon={DollarSign}
              label="Hourly Rate"
              value={`₦${tutor.hourlyRate.toLocaleString()}`}
              color="#2e8b57"
            />
            <QuickStat
              icon={TrendingUp}
              label="This Month"
              value={`₦${tutor.earnings.thisMonth.toLocaleString()}`}
              color="#6366f1"
            />
            <QuickStat
              icon={Heart}
              label="Retention"
              value={`${tutor.studentRetentionRate}%`}
              color="#ec4899"
            />
            <QuickStat
              icon={RotateCcw}
              label="Repeat Rate"
              value={`${tutor.repeatStudentRate}%`}
              color="#f97316"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* About & Teaching Style */}
            <div className="lg:col-span-2 space-y-6">
              <div
                className="p-6 rounded-2xl bg-white border"
                style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                <h3 className="font-serif text-lg text-green-900 mb-3">About</h3>
                {isEditing ? (
                  <textarea
                    value={editData.about}
                    onChange={(e) => setEditData({ ...editData, about: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 text-[14px] resize-none min-h-[100px] focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  />
                ) : (
                  <p className="text-[14px] text-text-muted leading-relaxed">{tutor.about}</p>
                )}
              </div>

              <div
                className="p-6 rounded-2xl bg-white border"
                style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                <h3 className="font-serif text-lg text-green-900 mb-3">Teaching Style</h3>
                {isEditing ? (
                  <textarea
                    value={editData.teachingStyle}
                    onChange={(e) => setEditData({ ...editData, teachingStyle: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 text-[14px] resize-none min-h-[100px] focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  />
                ) : (
                  <p className="text-[14px] text-text-muted leading-relaxed">
                    {tutor.teachingStyle}
                  </p>
                )}
              </div>

              {/* Packages */}
              <div
                className="p-6 rounded-2xl bg-white border"
                style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-serif text-lg text-green-900">Session Packages</h3>
                  {isEditing && (
                    <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-800 text-white text-[12px] font-medium hover:bg-green-700">
                      <Plus size={14} /> Add Package
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {tutor.packages.map((pkg: any, idx: number) => (
                    <div
                      key={idx}
                      className={`p-4 rounded-xl border-2 text-center relative ${pkg.popular ? "border-green-800 bg-green-50" : "border-gray-200"}`}>
                      {pkg.popular && (
                        <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-green-800 text-white text-[10px] font-bold">
                          Popular
                        </span>
                      )}
                      <h4 className="text-[14px] font-semibold text-green-900 mb-1">{pkg.name}</h4>
                      <p className="text-[11px] text-text-muted mb-2">{pkg.duration}</p>
                      <div className="text-xl font-bold text-green-900 mb-1">
                        ₦{pkg.price.toLocaleString()}
                      </div>
                      {pkg.savings > 0 && (
                        <p className="text-[11px] text-green-600 font-medium">
                          Save ₦{pkg.savings.toLocaleString()}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar Info */}
            <div className="space-y-6">
              {/* Personal Info */}
              <div
                className="p-6 rounded-2xl bg-white border"
                style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                <h3 className="font-serif text-lg text-green-900 mb-4">Personal Information</h3>
                <div className="space-y-3">
                  <InfoRow icon={Mail} label="Email" value={tutor.email} />
                  <InfoRow icon={Phone} label="Phone" value={tutor.phone} />
                  <InfoRow icon={MapPin} label="Location" value={`${tutor.city}, ${tutor.state}`} />
                  <InfoRow icon={Globe} label="Languages" value={tutor.languages.join(", ")} />
                  <InfoRow icon={Calendar} label="Joined" value={tutor.joinedDate} />
                  <InfoRow icon={Clock} label="Last Active" value={tutor.lastActive} />
                  <InfoRow
                    icon={Target}
                    label="Teaching Mode"
                    value={
                      tutor.teachingMode === "online"
                        ? "Online"
                        : tutor.teachingMode === "in_person"
                          ? "In-Person"
                          : "Both"
                    }
                  />
                </div>
              </div>

              {/* Availability */}
              <div
                className="p-6 rounded-2xl bg-white border"
                style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                <h3 className="font-serif text-lg text-green-900 mb-3">Availability</h3>
                <div className="flex flex-wrap gap-1 mb-3">
                  {tutor.availability.map((day: string) => (
                    <span
                      key={day}
                      className="px-3 py-1.5 rounded-lg bg-green-50 text-[12px] font-medium text-green-700">
                      {day}
                    </span>
                  ))}
                </div>
                <h4 className="text-[12px] font-semibold text-green-900 mb-2">Time Slots</h4>
                <div className="flex flex-wrap gap-1">
                  {tutor.timeSlots.map((slot: string) => (
                    <span
                      key={slot}
                      className="px-2.5 py-1 rounded-lg bg-cream/50 text-[11px] text-text-muted">
                      {slot}
                    </span>
                  ))}
                </div>
              </div>

              {/* Banking */}
              <div
                className="p-6 rounded-2xl bg-white border"
                style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                <h3 className="font-serif text-lg text-green-900 mb-3">Banking Details</h3>
                <div className="space-y-2">
                  <InfoRow icon={BuildingIcon} label="Bank" value={tutor.bankName} />
                  <InfoRow icon={HashIcon} label="Account" value={tutor.accountNumber} />
                  <InfoRow icon={Users} label="Name" value={tutor.accountName} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── SESSIONS TAB ─── */}
      {activeTab === "sessions" && (
        <div
          className="bg-white rounded-2xl border overflow-hidden"
          style={{ borderColor: "rgba(30,80,50,0.08)" }}>
          <div
            className="px-6 py-4 border-b flex items-center justify-between"
            style={{ borderColor: "rgba(30,80,50,0.08)" }}>
            <h3 className="font-serif text-lg text-green-900">Recent Sessions</h3>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-200 text-[13px] text-text-muted hover:bg-cream">
                <Download size={14} /> Export
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-800 text-white text-[13px] font-medium hover:bg-green-700">
                <Plus size={14} /> Schedule Session
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-cream/30 border-b" style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                  <th className="text-left px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Student
                  </th>
                  <th className="text-left px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Subject
                  </th>
                  <th className="text-left px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Date & Time
                  </th>
                  <th className="text-left px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Duration
                  </th>
                  <th className="text-center px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Status
                  </th>
                  <th className="text-right px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Amount
                  </th>
                  <th className="text-center px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Rating
                  </th>
                  <th className="text-center px-4 py-3 text-[12px] font-semibold text-text-muted">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y" style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                {tutor.recentSessions.map((session: any) => (
                  <tr key={session.id} className="hover:bg-cream/20 transition-colors">
                    <td className="px-4 py-3">
                      <div className="text-[13px] font-semibold text-green-900">
                        {session.studentName}
                      </div>
                      <div className="text-[11px] text-text-muted">{session.studentEmail}</div>
                    </td>
                    <td className="px-4 py-3 text-[13px] text-green-900">{session.subject}</td>
                    <td className="px-4 py-3">
                      <div className="text-[13px] text-green-900">{session.date}</div>
                      <div className="text-[11px] text-text-muted">{session.time}</div>
                    </td>
                    <td className="px-4 py-3 text-[13px] text-green-900">{session.duration} min</td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${
                          session.status === "completed"
                            ? "bg-green-100 text-green-600"
                            : session.status === "upcoming"
                              ? "bg-blue-100 text-blue-600"
                              : session.status === "in_progress"
                                ? "bg-yellow-100 text-yellow-600"
                                : "bg-red-100 text-red-600"
                        }`}>
                        {session.status.replace("_", " ")}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-[13px] font-bold text-green-900">
                      ₦{session.amount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {session.rating ? (
                        <span className="flex items-center justify-center gap-1 text-[13px] text-green-900">
                          <Star size={12} className="text-gold fill-gold" /> {session.rating}
                        </span>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="p-1.5 rounded-lg hover:bg-green-50">
                          <Eye size={14} className="text-text-muted" />
                        </button>
                        <button className="p-1.5 rounded-lg hover:bg-blue-50">
                          <Edit size={14} className="text-text-muted" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ─── REVIEWS TAB ─── */}
      {activeTab === "reviews" && (
        <div className="space-y-4">
          {tutor.recentReviews.map((review: any) => (
            <div
              key={review.id}
              className="p-5 rounded-2xl bg-white border"
              style={{ borderColor: "rgba(30,80,50,0.08)" }}>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-cream flex items-center justify-center overflow-hidden shrink-0">
                  {review.studentAvatar ? (
                    <img src={review.studentAvatar} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <Users size={18} className="text-green-800" />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <div>
                      <span className="text-[14px] font-semibold text-green-900">
                        {review.studentName}
                      </span>
                      <span className="text-[12px] text-text-muted ml-2">{review.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className={i < review.rating ? "text-gold fill-gold" : "text-gray-300"}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-[13px] text-text-muted mb-2">{review.comment}</p>
                  <div className="flex items-center gap-3 text-[11px] text-text-muted">
                    <span>Subject: {review.subject}</span>
                    <span>•</span>
                    <span>{review.sessionType}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <ThumbsUp size={10} /> {review.helpful} helpful
                    </span>
                  </div>

                  {/* Tutor Response */}
                  {review.response && (
                    <div className="mt-3 p-3 rounded-lg bg-green-50 border border-green-100">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[12px] font-semibold text-green-800">
                          {tutor.name}
                        </span>
                        <span className="text-[10px] text-text-muted">{review.responseDate}</span>
                      </div>
                      <p className="text-[12px] text-green-700">{review.response}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ─── EARNINGS TAB ─── */}
      {activeTab === "earnings" && (
        <div className="space-y-6">
          {/* Earnings Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <EarningsCard
              icon={DollarSign}
              label="Total Earnings"
              value={`₦${tutor.earnings.totalEarnings.toLocaleString()}`}
              color="#2e8b57"
            />
            <EarningsCard
              icon={TrendingUp}
              label="This Month"
              value={`₦${tutor.earnings.thisMonth.toLocaleString()}`}
              color="#10b981"
              trend={8}
            />
            <EarningsCard
              icon={Calendar}
              label="Last Month"
              value={`₦${tutor.earnings.lastMonth.toLocaleString()}`}
              color="#3b82f6"
            />
            <EarningsCard
              icon={Clock}
              label="Pending Payout"
              value={`₦${tutor.earnings.pendingPayout.toLocaleString()}`}
              color="#f59e0b"
            />
          </div>

          {/* Monthly Earnings Chart */}
          <div
            className="p-6 rounded-2xl bg-white border"
            style={{ borderColor: "rgba(30,80,50,0.08)" }}>
            <h3 className="font-serif text-lg text-green-900 mb-4">Monthly Earnings</h3>
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={tutor.earnings.monthlyBreakdown}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(30,80,50,0.1)" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6b7280" }} />
                <YAxis
                  tick={{ fontSize: 11, fill: "#6b7280" }}
                  tickFormatter={(v) => `₦${(v / 1000).toFixed(0)}K`}
                />
                <Tooltip
                  contentStyle={{ borderRadius: "8px", fontSize: "12px" }}
                  formatter={(value: number) => `₦${value.toLocaleString()}`}
                />
                <Bar dataKey="earnings" name="Earnings" fill="#2e8b57" radius={[4, 4, 0, 0]} />
                <Line
                  type="monotone"
                  dataKey="sessions"
                  name="Sessions"
                  stroke="#f59e0b"
                  strokeWidth={2}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Earnings by Subject */}
          <div
            className="p-6 rounded-2xl bg-white border"
            style={{ borderColor: "rgba(30,80,50,0.08)" }}>
            <h3 className="font-serif text-lg text-green-900 mb-4">Earnings by Subject</h3>
            <div className="grid grid-cols-3 gap-4">
              {tutor.earnings.earningsBySubject.map((item: any) => (
                <div key={item.subject} className="p-4 rounded-xl bg-cream/50 text-center">
                  <div className="text-lg font-bold text-green-900">
                    ₦{item.amount.toLocaleString()}
                  </div>
                  <div className="text-[12px] text-text-muted">{item.subject}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ─── DOCUMENTS TAB ─── */}
      {activeTab === "documents" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <DocumentCard label="CV / Resume" url={tutor.cvUrl} icon={FileText} />
          <DocumentCard label="ID Card" url={tutor.idCardUrl} icon={Shield} />
          {tutor.certificateUrls.map((url: string, idx: number) => (
            <DocumentCard key={idx} label={`Certificate ${idx + 1}`} url={url} icon={Award} />
          ))}
          <div className="p-8 rounded-2xl bg-white border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-green-800/30 transition-colors">
            <Upload size={32} className="text-gray-300 mb-2" />
            <span className="text-[13px] text-text-muted">Upload Document</span>
          </div>
        </div>
      )}

      {/* Suspend Confirmation Modal */}
      {showSuspendModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="font-serif text-xl text-green-900 mb-4">Suspend Tutor</h3>
            <p className="text-[14px] text-text-muted mb-6">
              Are you sure you want to suspend {tutor.name}? They will no longer be able to accept
              new sessions.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowSuspendModal(false)}
                className="flex-1 py-3 rounded-xl border-2 border-gray-200 text-[14px] font-semibold text-text-muted hover:bg-gray-50">
                Cancel
              </button>
              <button
                onClick={handleSuspend}
                className="flex-1 py-3 rounded-xl bg-red-500 text-white font-semibold hover:bg-red-600 transition-all text-[14px]">
                Suspend Tutor
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── HELPER COMPONENTS ─────────────────────────────────────
function QuickStat({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: any;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div
      className="p-3 rounded-2xl bg-white border transition-all hover:-translate-y-1"
      style={{ borderColor: "rgba(30,80,50,0.08)" }}>
      <div
        className="w-8 h-8 rounded-lg flex items-center justify-center mb-2"
        style={{ background: `${color}15` }}>
        <Icon size={14} style={{ color }} />
      </div>
      <div className="text-lg font-bold text-green-900">{value}</div>
      <div className="text-[11px] text-text-muted">{label}</div>
    </div>
  );
}

function EarningsCard({
  icon: Icon,
  label,
  value,
  color,
  trend,
}: {
  icon: any;
  label: string;
  value: string;
  color: string;
  trend?: number;
}) {
  return (
    <div className="p-5 rounded-2xl bg-white border" style={{ borderColor: "rgba(30,80,50,0.08)" }}>
      <div className="flex items-center justify-between mb-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ background: `${color}15` }}>
          <Icon size={18} style={{ color }} />
        </div>
        {trend && (
          <span
            className={`flex items-center gap-1 text-[11px] font-semibold ${trend >= 0 ? "text-green-600" : "text-red-500"}`}>
            {trend >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <div className="text-2xl font-bold text-green-900">{value}</div>
      <div className="text-[12px] text-text-muted">{label}</div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2">
      <Icon size={14} className="text-text-muted shrink-0" />
      <span className="text-[12px] text-text-muted">{label}:</span>
      <span className="text-[13px] font-semibold text-green-900 truncate">{value}</span>
    </div>
  );
}

function DocumentCard({ label, url, icon: Icon }: { label: string; url?: string; icon: any }) {
  return (
    <div
      className="p-5 rounded-2xl bg-white border flex items-center gap-4"
      style={{ borderColor: "rgba(30,80,50,0.08)" }}>
      <div className="w-12 h-12 rounded-xl bg-cream flex items-center justify-center">
        <Icon size={22} className="text-green-700" />
      </div>
      <div className="flex-1">
        <div className="text-[13px] font-semibold text-green-900">{label}</div>
        <div className="text-[11px] text-text-muted">{url ? "Uploaded" : "Not uploaded"}</div>
      </div>
      {url && (
        <div className="flex gap-1">
          <button className="p-2 rounded-lg hover:bg-green-50">
            <Eye size={14} className="text-text-muted" />
          </button>
          <button className="p-2 rounded-lg hover:bg-blue-50">
            <Download size={14} className="text-text-muted" />
          </button>
        </div>
      )}
    </div>
  );
}

// ─── COMPOSED CHART (re-export for this file) ──────────────
import { ComposedChart } from "recharts";

const BuildingIcon = ({ size, className }: any) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={2}
    className={className}>
    <rect x="4" y="2" width="16" height="20" rx="2" />
    <path d="M9 6h6M9 10h6M9 14h6M9 18h6" />
  </svg>
);

const HashIcon = ({ size, className }: any) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={2}
    className={className}>
    <line x1="4" y1="9" x2="20" y2="9" />
    <line x1="4" y1="15" x2="20" y2="15" />
    <line x1="10" y1="3" x2="8" y2="21" />
    <line x1="16" y1="3" x2="14" y2="21" />
  </svg>
);
