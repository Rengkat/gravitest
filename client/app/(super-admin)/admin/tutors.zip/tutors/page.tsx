"use client";

import { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import {
  Search,
  Filter,
  Plus,
  Download,
  Upload,
  X,
  Check,
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  Users,
  Star,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Calendar,
  Clock,
  Target,
  Zap,
  Award,
  BookOpen,
  Briefcase,
  GraduationCap,
  Shield,
  AlertCircle,
  BarChart3,
  BadgeCheck,
  ArrowUpDown,
  RefreshCw,
  Ban,
  UserCheck,
  UserX,
  UserPlus,
  Mail,
  Phone,
  MapPin,
  Globe,
  FilterX,
  Activity,
  Layers,
  Wrench,
  MessageSquare,
  Video,
  FileText,
  Image as ImageIcon,
  LayoutGrid,
  List,
  Table2,
  ArrowUpRight,
  Crown,
  Sparkles,
  Heart,
  ThumbsUp,
  School,
  SlidersHorizontal,
  Hash,
  Coins,
  Monitor,
  Smartphone,
  Flame,
  Brain,
  Microscope,
  PenLine,
  Calculator,
  Palette,
  Music,
  Languages,
  Landmark,
  Building2,
  Package,
  PauseCircleIcon,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ComposedChart,
} from "recharts";

// ─── TYPES ──────────────────────────────────────────────────
type TutorStatus = "active" | "inactive" | "suspended" | "pending" | "on_leave";
type VerificationLevel = "verified" | "unverified" | "pending" | "premium";
type TutorCategory = "secondary" | "professional";
type TeachingMode = "online" | "in_person" | "both";

type TutorSpecialization =
  | "mathematics"
  | "english"
  | "physics"
  | "chemistry"
  | "biology"
  | "economics"
  | "government"
  | "literature"
  | "commerce"
  | "geography"
  | "history"
  | "french"
  | "yoruba"
  | "hausa"
  | "igbo"
  | "agriculture"
  | "technical_drawing"
  | "further_mathematics"
  | "computer_studies"
  | "civic_education"
  | "business_studies"
  | "home_economics"
  | "physical_education"
  | "music"
  | "fine_arts"
  | "accounting"
  | "nursing"
  | "hr_management"
  | "estate_management";

interface TutorPackage {
  name: string;
  duration: string;
  price: number;
  savings: number;
  popular?: boolean;
  sessions: number;
}

interface Tutor {
  id: string;
  name: string;
  avatar?: string;
  title: string;
  email: string;
  phone: string;

  // Categories
  category: TutorCategory;
  specialization: TutorSpecialization[];
  subjects: string[];
  examTypes: string[];

  // Professional Info
  experience: number;
  education: string;
  certifications: string[];
  about: string;
  teachingStyle: string;

  // Platform Stats
  status: TutorStatus;
  verificationLevel: VerificationLevel;
  rating: number;
  reviewCount: number;
  totalStudents: number;
  totalSessions: number;
  completionRate: number;
  responseTime: string;
  isOnline: boolean;
  isFeatured: boolean;
  isVerified: boolean;
  joinedDate: string;
  lastActive: string;

  // Pricing
  hourlyRate: number;
  packages: TutorPackage[];

  // Location & Teaching
  state: string;
  city: string;
  teachingMode: TeachingMode;
  availability: string[];
  languages: string[];

  // Earnings
  totalEarnings: number;
  earningsThisMonth: number;
  platformCommission: number;

  // Tags
  tags: string[];
  achievements: string[];

  // Performance
  studentRetentionRate: number;
  repeatStudentRate: number;
  cancellationRate: number;
}

interface TutorStats {
  totalTutors: number;
  activeTutors: number;
  pendingVerification: number;
  suspendedTutors: number;
  onLeaveTutors: number;

  secondaryTutors: number;
  professionalTutors: number;

  onlineTutors: number;
  inPersonTutors: number;

  averageRating: number;
  averageHourlyRate: number;
  averageExperience: number;

  totalStudents: number;
  totalSessionsCompleted: number;
  totalRevenue: number;
  platformCommission: number;

  verifiedPercentage: number;
  featuredTutors: number;

  topSpecializations: { subject: string; count: number; color: string }[];
  tutorsByState: { state: string; count: number }[];
  tutorsByExperience: { range: string; count: number }[];
  monthlyOnboarding: { month: string; count: number }[];
  revenueByCategory: { category: string; revenue: number; count: number }[];
  performanceDistribution: { rating: string; count: number; color: string }[];
  teachingModeBreakdown: { mode: string; count: number; color: string }[];
}

// ─── CONSTANTS ──────────────────────────────────────────────
const SPECIALIZATIONS: Record<
  TutorSpecialization,
  { label: string; color: string; bg: string; icon: any; category: TutorCategory }
> = {
  mathematics: {
    label: "Mathematics",
    color: "#2e8b57",
    bg: "#2e8b5715",
    icon: Hash,
    category: "secondary",
  },
  english: {
    label: "English",
    color: "#3b82f6",
    bg: "#3b82f615",
    icon: BookOpen,
    category: "secondary",
  },
  physics: {
    label: "Physics",
    color: "#ef4444",
    bg: "#ef444415",
    icon: Zap,
    category: "secondary",
  },
  chemistry: {
    label: "Chemistry",
    color: "#8b5cf6",
    bg: "#8b5cf615",
    icon: Microscope,
    category: "secondary",
  },
  biology: {
    label: "Biology",
    color: "#10b981",
    bg: "#10b98115",
    icon: Heart,
    category: "secondary",
  },
  economics: {
    label: "Economics",
    color: "#f59e0b",
    bg: "#f59e0b15",
    icon: TrendingUp,
    category: "secondary",
  },
  government: {
    label: "Government",
    color: "#6366f1",
    bg: "#6366f115",
    icon: Landmark,
    category: "secondary",
  },
  literature: {
    label: "Literature",
    color: "#ec4899",
    bg: "#ec489915",
    icon: PenLine,
    category: "secondary",
  },
  commerce: {
    label: "Commerce",
    color: "#14b8a6",
    bg: "#14b8a615",
    icon: Briefcase,
    category: "secondary",
  },
  geography: {
    label: "Geography",
    color: "#f97316",
    bg: "#f9731615",
    icon: Globe,
    category: "secondary",
  },
  history: {
    label: "History",
    color: "#a855f7",
    bg: "#a855f715",
    icon: Clock,
    category: "secondary",
  },
  french: {
    label: "French",
    color: "#06b6d4",
    bg: "#06b6d415",
    icon: Languages,
    category: "secondary",
  },
  yoruba: {
    label: "Yoruba",
    color: "#84cc16",
    bg: "#84cc1615",
    icon: Languages,
    category: "secondary",
  },
  hausa: {
    label: "Hausa",
    color: "#eab308",
    bg: "#eab30815",
    icon: Languages,
    category: "secondary",
  },
  igbo: {
    label: "Igbo",
    color: "#22c55e",
    bg: "#22c55e15",
    icon: Languages,
    category: "secondary",
  },
  agriculture: {
    label: "Agriculture",
    color: "#15803d",
    bg: "#15803d15",
    icon: BookOpen,
    category: "secondary",
  },
  technical_drawing: {
    label: "Technical Drawing",
    color: "#475569",
    bg: "#47556915",
    icon: PenLine,
    category: "secondary",
  },
  further_mathematics: {
    label: "Further Maths",
    color: "#7c3aed",
    bg: "#7c3aed15",
    icon: Brain,
    category: "secondary",
  },
  computer_studies: {
    label: "Computer Studies",
    color: "#0891b2",
    bg: "#0891b215",
    icon: Monitor,
    category: "secondary",
  },
  civic_education: {
    label: "Civic Education",
    color: "#dc2626",
    bg: "#dc262615",
    icon: Shield,
    category: "secondary",
  },
  business_studies: {
    label: "Business Studies",
    color: "#ca8a04",
    bg: "#ca8a0415",
    icon: Briefcase,
    category: "secondary",
  },
  home_economics: {
    label: "Home Economics",
    color: "#be185d",
    bg: "#be185d15",
    icon: Heart,
    category: "secondary",
  },
  physical_education: {
    label: "PHE",
    color: "#1d4ed8",
    bg: "#1d4ed815",
    icon: Activity,
    category: "secondary",
  },
  music: { label: "Music", color: "#9333ea", bg: "#9333ea15", icon: Music, category: "secondary" },
  fine_arts: {
    label: "Fine Arts",
    color: "#c2410c",
    bg: "#c2410c15",
    icon: Palette,
    category: "secondary",
  },
  accounting: {
    label: "Accounting",
    color: "#0891b2",
    bg: "#0891b215",
    icon: Calculator,
    category: "professional",
  },
  nursing: {
    label: "Nursing",
    color: "#dc2626",
    bg: "#dc262615",
    icon: Heart,
    category: "professional",
  },
  hr_management: {
    label: "HR Management",
    color: "#7c3aed",
    bg: "#7c3aed15",
    icon: Users,
    category: "professional",
  },
  estate_management: {
    label: "Estate Management",
    color: "#d97706",
    bg: "#d9770615",
    icon: Building2,
    category: "professional",
  },
};

const STATUS_CONFIG: Record<TutorStatus, { label: string; bg: string; text: string; icon: any }> = {
  active: { label: "Active", bg: "#10b98115", text: "#10b981", icon: Check },
  inactive: { label: "Inactive", bg: "#6b728015", text: "#6b7280", icon: X },
  suspended: { label: "Suspended", bg: "#ef444415", text: "#ef4444", icon: Ban },
  pending: { label: "Pending", bg: "#f59e0b15", text: "#f59e0b", icon: Clock },
  on_leave: { label: "On Leave", bg: "#3b82f615", text: "#3b82f6", icon: PauseCircleIcon },
};

const VERIFICATION_CONFIG: Record<
  VerificationLevel,
  { label: string; bg: string; text: string; icon: any }
> = {
  verified: { label: "Verified", bg: "#10b98115", text: "#10b981", icon: BadgeCheck },
  unverified: { label: "Unverified", bg: "#6b728015", text: "#6b7280", icon: Shield },
  pending: { label: "Pending", bg: "#f59e0b15", text: "#f59e0b", icon: Clock },
  premium: { label: "Premium", bg: "#8b5cf615", text: "#8b5cf6", icon: Crown },
};

const CATEGORY_CONFIG: Record<
  TutorCategory,
  { label: string; icon: any; color: string; bg: string }
> = {
  secondary: { label: "Secondary School", icon: GraduationCap, color: "#2e8b57", bg: "#2e8b5715" },
  professional: { label: "Professional", icon: Briefcase, color: "#7c3aed", bg: "#7c3aed15" },
};

const NIGERIAN_STATES = [
  "Abia",
  "Adamawa",
  "Akwa Ibom",
  "Anambra",
  "Bauchi",
  "Bayelsa",
  "Benue",
  "Borno",
  "Cross River",
  "Delta",
  "Ebonyi",
  "Edo",
  "Ekiti",
  "Enugu",
  "FCT",
  "Gombe",
  "Imo",
  "Jigawa",
  "Kaduna",
  "Kano",
  "Katsina",
  "Kebbi",
  "Kogi",
  "Kwara",
  "Lagos",
  "Nasarawa",
  "Niger",
  "Ogun",
  "Ondo",
  "Osun",
  "Oyo",
  "Plateau",
  "Rivers",
  "Sokoto",
  "Taraba",
  "Yobe",
  "Zamfara",
];

const EXPERIENCE_RANGES = ["0-2 years", "3-5 years", "6-10 years", "11-15 years", "16+ years"];

// ─── MOCK DATA GENERATOR ────────────────────────────────────
function buildPackages(hourly: number): TutorPackage[] {
  return [
    { name: "Single Session", duration: "1 hour", price: hourly, savings: 0, sessions: 1 },
    {
      name: "5 Sessions Pack",
      duration: "5 hours",
      price: hourly * 5 - Math.round(hourly * 0.07),
      savings: Math.round(hourly * 0.35),
      sessions: 5,
      popular: true,
    },
    {
      name: "10 Sessions Pack",
      duration: "10 hours",
      price: hourly * 10 - Math.round(hourly * 1.5),
      savings: Math.round(hourly * 1.5),
      sessions: 10,
    },
    {
      name: "Monthly Plan",
      duration: "8 hrs/month",
      price: Math.round(hourly * 8 * 0.8),
      savings: Math.round(hourly * 8 * 0.2),
      sessions: 8,
    },
  ];
}

function generateMockTutors(count: number): Tutor[] {
  const secondarySpecs: TutorSpecialization[] = [
    "mathematics",
    "english",
    "physics",
    "chemistry",
    "biology",
    "economics",
    "government",
    "literature",
    "commerce",
    "geography",
    "further_mathematics",
    "technical_drawing",
    "agriculture",
    "computer_studies",
    "french",
    "yoruba",
    "hausa",
    "igbo",
    "civic_education",
    "business_studies",
  ];

  const professionalSpecs: TutorSpecialization[] = [
    "accounting",
    "nursing",
    "hr_management",
    "estate_management",
  ];

  const tutorNames = [
    { name: "Dr. Adebayo Ola", title: "PhD Mathematics — 15+ years experience" },
    { name: "Prof. Chukwuma Eze", title: "Physics Specialist — Former WAEC Examiner" },
    { name: "Mrs. Grace Okonkwo", title: "Chemistry & Biology Expert — MSc UNN" },
    { name: "Mr. Segun Adeyemi", title: "English Literature & Language Coach" },
    { name: "Dr. Funmilayo Adebayo", title: "Economics & Government Specialist" },
    { name: "Mr. Michael Okafor", title: "Mathematics & Further Maths Tutor" },
    { name: "Dr. Ifeoma Obi", title: "Biology & Health Science Specialist" },
    { name: "Mr. Tunde Adesanya", title: "Government & History Teacher" },
    { name: "Mrs. Amaka Nwosu", title: "Economics & Commerce Expert" },
    { name: "Dr. Ibrahim Musa", title: "Physics & Technical Drawing Specialist" },
    { name: "Ms. Aisha Bello", title: "English & Literature Tutor" },
    { name: "Mr. David Okafor", title: "Chemistry & Biology Teacher" },
    { name: "Mrs. Fatima Suleiman", title: "Mathematics & Computer Studies" },
    { name: "Dr. Emeka Nwachukwu", title: "Physics & Further Maths Expert" },
    { name: "Mr. Oluwaseun Adeyemi", title: "Government & Civic Education" },
  ];

  return Array.from({ length: count }, (_, i) => {
    const isProfessional = Math.random() > 0.8;
    const category: TutorCategory = isProfessional ? "professional" : "secondary";
    const specs = isProfessional ? professionalSpecs : secondarySpecs;
    const numSpecs = Math.floor(Math.random() * 3) + 1;
    const tutorSpecs = specs
      .sort(() => Math.random() - 0.5)
      .slice(0, numSpecs) as TutorSpecialization[];

    const tutorName = tutorNames[i % tutorNames.length];
    const hourlyRate = isProfessional
      ? Math.floor(Math.random() * 10000 + 15000)
      : Math.floor(Math.random() * 8000 + 5000);
    const totalSessions = Math.floor(Math.random() * 3500) + 200;
    const monthlyEarnings = Math.floor(Math.random() * 300000 + 80000);

    return {
      id: `tutor_${(i + 1).toString().padStart(4, "0")}`,
      name: tutorName.name,
      avatar: `https://i.pravatar.cc/150?u=tutor${i}`,
      title: tutorName.title,
      email: `${tutorName.name
        .toLowerCase()
        .replace(/ /g, ".")
        .replace(/[^a-z.]/g, "")}@graviest.com`,
      phone: `+234${Math.floor(Math.random() * 900000000 + 100000000)}`,

      category,
      specialization: tutorSpecs,
      subjects: tutorSpecs.map((s) => SPECIALIZATIONS[s]?.label || s),
      examTypes: isProfessional
        ? ["ICAN", "NMCN", "CIPM", "NIM", "NIESV"].slice(0, Math.floor(Math.random() * 2) + 1)
        : ["JAMB", "WAEC", "NECO", "NABTEB", "BECE"].slice(0, Math.floor(Math.random() * 3) + 1),

      experience: Math.floor(Math.random() * 20) + 1,
      education: ["PhD", "MSc", "BSc", "BEd", "MA", "MBBS", "HND"][Math.floor(Math.random() * 7)],
      certifications: [
        "Certified Educator",
        "WAEC Examiner",
        "TRCN Certified",
        "NUC Lecturer",
        "ICAN Certified",
      ].slice(0, Math.floor(Math.random() * 3) + 1),
      about: `${tutorName.name} is a dedicated educator with extensive experience.`,
      teachingStyle: "Interactive and student-centered approach.",

      status: [
        "active",
        "active",
        "active",
        "active",
        "inactive",
        "pending",
        "on_leave",
        "suspended",
      ][Math.floor(Math.random() * 8)] as TutorStatus,
      verificationLevel: ["verified", "verified", "verified", "pending", "premium", "unverified"][
        Math.floor(Math.random() * 6)
      ] as VerificationLevel,
      rating: 3.5 + Math.random() * 1.5,
      reviewCount: Math.floor(Math.random() * 900) + 50,
      totalStudents: Math.floor(Math.random() * 1200) + 100,
      totalSessions,
      completionRate: 80 + Math.floor(Math.random() * 20),
      responseTime: ["< 30 mins", "< 1 hour", "< 2 hours", "< 4 hours"][
        Math.floor(Math.random() * 4)
      ],
      isOnline: Math.random() > 0.3,
      isFeatured: Math.random() > 0.85,
      isVerified: Math.random() > 0.2,
      joinedDate: new Date(2023, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1)
        .toISOString()
        .split("T")[0],
      lastActive: new Date(2025, 2, Math.floor(Math.random() * 28) + 1).toISOString().split("T")[0],

      hourlyRate,
      packages: buildPackages(hourlyRate),

      state: NIGERIAN_STATES[Math.floor(Math.random() * NIGERIAN_STATES.length)],
      city: [
        "Ikeja",
        "Surulere",
        "Wuse",
        "Garki",
        "Ibadan",
        "Enugu",
        "Port Harcourt",
        "Kaduna",
        "Benin City",
        "Jos",
      ][Math.floor(Math.random() * 10)],
      teachingMode: ["online", "in_person", "both"][Math.floor(Math.random() * 3)] as TeachingMode,
      availability: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].slice(
        0,
        Math.floor(Math.random() * 4) + 3,
      ),
      languages: [
        "English",
        ...["Yoruba", "Igbo", "Hausa"].slice(0, Math.floor(Math.random() * 2)),
      ],

      totalEarnings: monthlyEarnings * (Math.floor(Math.random() * 18) + 6),
      earningsThisMonth: monthlyEarnings,
      platformCommission: Math.floor(monthlyEarnings * 0.2),

      tags: [
        "JAMB Expert",
        "WAEC Specialist",
        "Quick Response",
        "Patient Teacher",
        "Exam Strategy",
        "Practical Focus",
        "Affordable",
      ].slice(0, Math.floor(Math.random() * 4) + 2),
      achievements: [
        "Best Tutor Award 2023",
        "Helped 500+ students",
        "Published author",
        "Featured in Education Magazine",
      ].slice(0, Math.floor(Math.random() * 3) + 1),

      studentRetentionRate: 55 + Math.floor(Math.random() * 40),
      repeatStudentRate: 35 + Math.floor(Math.random() * 55),
      cancellationRate: Math.floor(Math.random() * 15),
    };
  });
}

function generateTutorStats(tutors: Tutor[]): TutorStats {
  const activeTutors = tutors.filter((t) => t.status === "active");
  const secondaryTutors = tutors.filter((t) => t.category === "secondary");
  const professionalTutors = tutors.filter((t) => t.category === "professional");

  const specCount: Record<string, number> = {};
  tutors.forEach((t) => {
    t.specialization.forEach((s) => {
      specCount[s] = (specCount[s] || 0) + 1;
    });
  });

  const stateCount: Record<string, number> = {};
  tutors.forEach((t) => {
    stateCount[t.state] = (stateCount[t.state] || 0) + 1;
  });

  const experienceCount: Record<string, number> = {
    "0-2 years": 0,
    "3-5 years": 0,
    "6-10 years": 0,
    "11-15 years": 0,
    "16+ years": 0,
  };
  tutors.forEach((t) => {
    if (t.experience <= 2) experienceCount["0-2 years"]++;
    else if (t.experience <= 5) experienceCount["3-5 years"]++;
    else if (t.experience <= 10) experienceCount["6-10 years"]++;
    else if (t.experience <= 15) experienceCount["11-15 years"]++;
    else experienceCount["16+ years"]++;
  });

  const ratingColors = ["#10b981", "#22c55e", "#f59e0b", "#f97316", "#ef4444"];

  return {
    totalTutors: tutors.length,
    activeTutors: activeTutors.length,
    pendingVerification: tutors.filter((t) => t.verificationLevel === "pending").length,
    suspendedTutors: tutors.filter((t) => t.status === "suspended").length,
    onLeaveTutors: tutors.filter((t) => t.status === "on_leave").length,

    secondaryTutors: secondaryTutors.length,
    professionalTutors: professionalTutors.length,

    onlineTutors: tutors.filter((t) => t.isOnline).length,
    inPersonTutors: tutors.filter(
      (t) => t.teachingMode === "in_person" || t.teachingMode === "both",
    ).length,

    averageRating:
      tutors.length > 0
        ? parseFloat((tutors.reduce((s, t) => s + t.rating, 0) / tutors.length).toFixed(1))
        : 0,
    averageHourlyRate:
      tutors.length > 0
        ? Math.round(tutors.reduce((s, t) => s + t.hourlyRate, 0) / tutors.length)
        : 0,
    averageExperience:
      tutors.length > 0
        ? Math.round(tutors.reduce((s, t) => s + t.experience, 0) / tutors.length)
        : 0,

    totalStudents: tutors.reduce((s, t) => s + t.totalStudents, 0),
    totalSessionsCompleted: tutors.reduce((s, t) => s + t.totalSessions, 0),
    totalRevenue: tutors.reduce((s, t) => s + t.totalEarnings, 0),
    platformCommission: Math.round(tutors.reduce((s, t) => s + t.totalEarnings, 0) * 0.2),

    verifiedPercentage:
      tutors.length > 0
        ? Math.round((tutors.filter((t) => t.isVerified).length / tutors.length) * 100)
        : 0,
    featuredTutors: tutors.filter((t) => t.isFeatured).length,

    topSpecializations: Object.entries(specCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 8)
      .map(([subject, count], i) => ({
        subject: SPECIALIZATIONS[subject as TutorSpecialization]?.label || subject,
        count,
        color: SPECIALIZATIONS[subject as TutorSpecialization]?.color || "#6b7280",
      })),

    tutorsByState: Object.entries(stateCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([state, count]) => ({ state, count })),

    tutorsByExperience: Object.entries(experienceCount).map(([range, count]) => ({ range, count })),

    monthlyOnboarding: Array.from({ length: 12 }, (_, i) => ({
      month: new Date(2024, i, 1).toLocaleString("default", { month: "short" }),
      count: Math.floor(Math.random() * 15 + 5),
    })),

    revenueByCategory: [
      {
        category: "Secondary",
        revenue: secondaryTutors.reduce((s, t) => s + t.totalEarnings, 0),
        count: secondaryTutors.length,
      },
      {
        category: "Professional",
        revenue: professionalTutors.reduce((s, t) => s + t.totalEarnings, 0),
        count: professionalTutors.length,
      },
    ],

    performanceDistribution: [
      {
        rating: "4.5-5.0",
        count: tutors.filter((t) => t.rating >= 4.5).length,
        color: ratingColors[0],
      },
      {
        rating: "4.0-4.4",
        count: tutors.filter((t) => t.rating >= 4.0 && t.rating < 4.5).length,
        color: ratingColors[1],
      },
      {
        rating: "3.5-3.9",
        count: tutors.filter((t) => t.rating >= 3.5 && t.rating < 4.0).length,
        color: ratingColors[2],
      },
      {
        rating: "3.0-3.4",
        count: tutors.filter((t) => t.rating >= 3.0 && t.rating < 3.5).length,
        color: ratingColors[3],
      },
      {
        rating: "<3.0",
        count: tutors.filter((t) => t.rating < 3.0).length,
        color: ratingColors[4],
      },
    ],

    teachingModeBreakdown: [
      {
        mode: "Online",
        count: tutors.filter((t) => t.teachingMode === "online").length,
        color: "#3b82f6",
      },
      {
        mode: "In-Person",
        count: tutors.filter((t) => t.teachingMode === "in_person").length,
        color: "#10b981",
      },
      {
        mode: "Both",
        count: tutors.filter((t) => t.teachingMode === "both").length,
        color: "#8b5cf6",
      },
    ],
  };
}

// ─── MAIN COMPONENT ────────────────────────────────────────
export default function AdminTutorsPage() {
  const [tutors, setTutors] = useState<Tutor[]>([]);
  const [stats, setStats] = useState<TutorStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<"analytics" | "grid" | "list">("analytics");
  const [categoryFilter, setCategoryFilter] = useState<"all" | TutorCategory>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [showAddTutor, setShowAddTutor] = useState(false);
  const [selectedTutors, setSelectedTutors] = useState<Set<string>>(new Set());
  const [showBulkActions, setShowBulkActions] = useState(false);

  // Filters
  const [filters, setFilters] = useState({
    status: "" as TutorStatus | "",
    verification: "" as VerificationLevel | "",
    specialization: "" as string,
    state: "",
    teachingMode: "" as TeachingMode | "",
    minRating: "",
    minExperience: "",
    maxExperience: "",
    minRate: "",
    maxRate: "",
    isOnline: "",
  });

  // Sorting
  const [sortField, setSortField] = useState<
    "name" | "rating" | "students" | "sessions" | "earnings" | "experience" | "hourlyRate"
  >("rating");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      const generatedTutors = generateMockTutors(55);
      setTutors(generatedTutors);
      setStats(generateTutorStats(generatedTutors));
      setLoading(false);
    }, 800);
  }, []);

  // ─── COMPUTED VALUES ─────────────────────────────────────
  const filteredTutors = useMemo(() => {
    return tutors
      .filter((tutor) => {
        if (categoryFilter !== "all" && tutor.category !== categoryFilter) return false;

        if (searchQuery) {
          const q = searchQuery.toLowerCase();
          if (
            !tutor.name.toLowerCase().includes(q) &&
            !tutor.email.toLowerCase().includes(q) &&
            !tutor.title.toLowerCase().includes(q) &&
            !tutor.subjects.some((s) => s.toLowerCase().includes(q)) &&
            !tutor.tags.some((t) => t.toLowerCase().includes(q)) &&
            !tutor.state.toLowerCase().includes(q)
          )
            return false;
        }

        if (filters.status && tutor.status !== filters.status) return false;
        if (filters.verification && tutor.verificationLevel !== filters.verification) return false;
        if (
          filters.specialization &&
          !tutor.specialization.includes(filters.specialization as TutorSpecialization)
        )
          return false;
        if (filters.state && tutor.state !== filters.state) return false;
        if (filters.teachingMode && tutor.teachingMode !== filters.teachingMode) return false;
        if (filters.minRating && tutor.rating < parseFloat(filters.minRating)) return false;
        if (filters.minExperience && tutor.experience < parseInt(filters.minExperience))
          return false;
        if (filters.maxExperience && tutor.experience > parseInt(filters.maxExperience))
          return false;
        if (filters.minRate && tutor.hourlyRate < parseInt(filters.minRate)) return false;
        if (filters.maxRate && tutor.hourlyRate > parseInt(filters.maxRate)) return false;
        if (filters.isOnline === "true" && !tutor.isOnline) return false;
        if (filters.isOnline === "false" && tutor.isOnline) return false;

        return true;
      })
      .sort((a, b) => {
        let cmp = 0;
        switch (sortField) {
          case "name":
            cmp = a.name.localeCompare(b.name);
            break;
          case "rating":
            cmp = a.rating - b.rating;
            break;
          case "students":
            cmp = a.totalStudents - b.totalStudents;
            break;
          case "sessions":
            cmp = a.totalSessions - b.totalSessions;
            break;
          case "earnings":
            cmp = a.totalEarnings - b.totalEarnings;
            break;
          case "experience":
            cmp = a.experience - b.experience;
            break;
          case "hourlyRate":
            cmp = a.hourlyRate - b.hourlyRate;
            break;
        }
        return sortDirection === "asc" ? cmp : -cmp;
      });
  }, [tutors, categoryFilter, searchQuery, filters, sortField, sortDirection]);

  const paginatedTutors = filteredTutors.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );
  const totalPages = Math.ceil(filteredTutors.length / itemsPerPage);
  const activeFilterCount =
    Object.values(filters).filter((v) => v !== "").length + (categoryFilter !== "all" ? 1 : 0);

  const clearFilters = () => {
    setFilters({
      status: "",
      verification: "",
      specialization: "",
      state: "",
      teachingMode: "",
      minRating: "",
      minExperience: "",
      maxExperience: "",
      minRate: "",
      maxRate: "",
      isOnline: "",
    });
    setCategoryFilter("all");
    setSearchQuery("");
  };

  const handleSelectAll = () => {
    if (selectedTutors.size === paginatedTutors.length) {
      setSelectedTutors(new Set());
    } else {
      setSelectedTutors(new Set(paginatedTutors.map((t) => t.id)));
    }
  };

  const handleSelectTutor = (id: string) => {
    const newSet = new Set(selectedTutors);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedTutors(newSet);
  };

  const handleBulkAction = (action: string) => {
    setTutors((prev) =>
      prev.map((t) => {
        if (selectedTutors.has(t.id)) {
          if (action === "activate") return { ...t, status: "active" as TutorStatus };
          if (action === "suspend") return { ...t, status: "suspended" as TutorStatus };
          if (action === "verify")
            return { ...t, verificationLevel: "verified" as VerificationLevel };
        }
        return t;
      }),
    );
    setSelectedTutors(new Set());
    setShowBulkActions(false);
  };

  const handleExport = () => {
    const csv = [
      [
        "Name",
        "Email",
        "Category",
        "Specialization",
        "Rating",
        "Students",
        "Sessions",
        "Hourly Rate",
        "Status",
        "State",
        "Total Earnings",
      ].join(","),
      ...filteredTutors.map((t) =>
        [
          t.name,
          t.email,
          t.category,
          t.specialization.map((s) => SPECIALIZATIONS[s]?.label).join("; "),
          t.rating,
          t.totalStudents,
          t.totalSessions,
          t.hourlyRate,
          t.status,
          t.state,
          t.totalEarnings,
        ].join(","),
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `tutors_export_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-64 bg-gray-200 rounded" />
          <div className="grid grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded-2xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="font-serif text-3xl text-green-900 mb-2">Tutor Management</h1>
            <p className="text-text-muted">
              Manage all {stats?.totalTutors || 0} tutors across secondary and professional
              categories.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExport}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-gray-200 hover:bg-cream transition-all text-[14px] font-medium text-text-muted">
              <Download size={16} /> Export
            </button>
            <button
              onClick={() => setShowAddTutor(true)}
              className="flex items-center gap-2 px-5 py-3 bg-green-800 text-white rounded-xl hover:bg-green-700 transition-all shadow-lg hover:shadow-xl font-semibold text-sm">
              <UserPlus size={18} /> Add Tutor
            </button>
          </div>
        </div>

        {/* View Toggle & Category Filter */}
        <div className="flex items-center gap-2 mt-4 flex-wrap">
          {(
            [
              { key: "analytics", label: "Analytics", icon: BarChart3 },
              { key: "grid", label: "Grid View", icon: LayoutGrid },
              { key: "list", label: "List View", icon: List },
            ] as const
          ).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setViewMode(key)}
              className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-all flex items-center gap-2 ${
                viewMode === key
                  ? "bg-green-800 text-white"
                  : "bg-white border border-gray-200 text-text-muted hover:bg-cream"
              }`}>
              <Icon size={14} /> {label}
            </button>
          ))}

          <div className="w-px h-8 bg-gray-200 mx-2" />

          <button
            onClick={() => setCategoryFilter("all")}
            className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-all ${
              categoryFilter === "all"
                ? "bg-green-800 text-white"
                : "bg-white border border-gray-200 text-text-muted hover:bg-cream"
            }`}>
            All Tutors
          </button>
          <button
            onClick={() => setCategoryFilter("secondary")}
            className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-all flex items-center gap-2 ${
              categoryFilter === "secondary"
                ? "bg-green-800 text-white"
                : "bg-white border border-gray-200 text-text-muted hover:bg-cream"
            }`}>
            <GraduationCap size={14} /> Secondary ({stats?.secondaryTutors || 0})
          </button>
          <button
            onClick={() => setCategoryFilter("professional")}
            className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-all flex items-center gap-2 ${
              categoryFilter === "professional"
                ? "bg-green-800 text-white"
                : "bg-white border border-gray-200 text-text-muted hover:bg-cream"
            }`}>
            <Briefcase size={14} /> Professional ({stats?.professionalTutors || 0})
          </button>
        </div>
      </div>

      {/* ─── ANALYTICS VIEW ─── */}
      {viewMode === "analytics" && stats && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
            <MiniCard icon={Users} label="Total Tutors" value={stats.totalTutors} color="#2e8b57" />
            <MiniCard icon={Check} label="Active" value={stats.activeTutors} color="#10b981" />
            <MiniCard
              icon={Clock}
              label="Pending"
              value={stats.pendingVerification}
              color="#f59e0b"
            />
            <MiniCard icon={Ban} label="Suspended" value={stats.suspendedTutors} color="#ef4444" />
            <MiniCard
              icon={Star}
              label="Avg Rating"
              value={stats.averageRating.toFixed(1)}
              color="#f59e0b"
            />
            <MiniCard
              icon={DollarSign}
              label="Avg Rate"
              value={`₦${(stats.averageHourlyRate / 1000).toFixed(0)}K`}
              color="#3b82f6"
            />
            <MiniCard
              icon={GraduationCap}
              label="Secondary"
              value={stats.secondaryTutors}
              color="#2e8b57"
            />
            <MiniCard
              icon={Briefcase}
              label="Professional"
              value={stats.professionalTutors}
              color="#7c3aed"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Status Distribution */}
            <div
              className="p-6 rounded-2xl bg-white border"
              style={{ borderColor: "rgba(30,80,50,0.08)" }}>
              <h3 className="font-serif text-lg text-green-900 mb-4">Status Distribution</h3>
              <div className="space-y-3">
                {Object.entries(STATUS_CONFIG).map(([key, config]) => {
                  const Icon = config.icon;
                  const count =
                    key === "active"
                      ? stats.activeTutors
                      : key === "inactive"
                        ? tutors.filter((t) => t.status === "inactive").length
                        : key === "suspended"
                          ? stats.suspendedTutors
                          : key === "pending"
                            ? stats.pendingVerification
                            : stats.onLeaveTutors;
                  return (
                    <div key={key} className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ background: config.bg }}>
                        <Icon size={14} style={{ color: config.text }} />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <span className="text-[13px] text-green-900">{config.label}</span>
                          <span className="text-[13px] font-bold text-green-900">{count}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Performance Distribution */}
            <div
              className="p-6 rounded-2xl bg-white border"
              style={{ borderColor: "rgba(30,80,50,0.08)" }}>
              <h3 className="font-serif text-lg text-green-900 mb-4">Rating Distribution</h3>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={stats.performanceDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={70}
                    paddingAngle={2}
                    dataKey="count"
                    nameKey="rating">
                    {stats.performanceDistribution.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Experience Distribution */}
            <div
              className="p-6 rounded-2xl bg-white border"
              style={{ borderColor: "rgba(30,80,50,0.08)" }}>
              <h3 className="font-serif text-lg text-green-900 mb-4">Experience Levels</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={stats.tutorsByExperience} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(30,80,50,0.1)" />
                  <XAxis type="number" tick={{ fontSize: 10 }} />
                  <YAxis type="category" dataKey="range" tick={{ fontSize: 10 }} width={80} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#2e8b57" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top Specializations & States */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div
              className="p-6 rounded-2xl bg-white border"
              style={{ borderColor: "rgba(30,80,50,0.08)" }}>
              <h3 className="font-serif text-lg text-green-900 mb-4">Top Specializations</h3>
              <div className="space-y-3">
                {stats.topSpecializations.map((spec, i) => (
                  <div key={spec.subject} className="flex items-center gap-3">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold"
                      style={{ background: `${spec.color}15`, color: spec.color }}>
                      {i + 1}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="text-[13px] text-green-900">{spec.subject}</span>
                        <span className="text-[13px] font-bold text-green-900">{spec.count}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-cream">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${(spec.count / stats.topSpecializations[0].count) * 100}%`,
                            background: spec.color,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div
              className="p-6 rounded-2xl bg-white border"
              style={{ borderColor: "rgba(30,80,50,0.08)" }}>
              <h3 className="font-serif text-lg text-green-900 mb-4">Tutors by State</h3>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {stats.tutorsByState.map((item) => (
                  <div key={item.state} className="flex items-center justify-between py-1.5">
                    <span className="text-[13px] text-green-900">{item.state}</span>
                    <span className="text-[13px] font-bold text-green-900">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Monthly Onboarding Chart */}
          <div
            className="p-6 rounded-2xl bg-white border"
            style={{ borderColor: "rgba(30,80,50,0.08)" }}>
            <h3 className="font-serif text-lg text-green-900 mb-4">Tutor Onboarding Trend</h3>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={stats.monthlyOnboarding}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(30,80,50,0.1)" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6b7280" }} />
                <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} />
                <Tooltip contentStyle={{ borderRadius: "8px" }} />
                <Area
                  type="monotone"
                  dataKey="count"
                  stroke="#2e8b57"
                  fill="#2e8b5720"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* ─── GRID / LIST VIEWS ─── */}
      {(viewMode === "grid" || viewMode === "list") && (
        <>
          {/* Search & Filters */}
          <div
            className="bg-white rounded-2xl border p-4 mb-6"
            style={{ borderColor: "rgba(30,80,50,0.08)" }}>
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search
                  size={18}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted"
                />
                <input
                  type="text"
                  placeholder="Search by name, email, subject, state, or tags..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 text-[14px] focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-400 transition-all"
                />
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl border transition-all text-[14px] font-medium ${
                    showFilters || activeFilterCount > 0
                      ? "bg-green-800 text-white border-green-800"
                      : "bg-white text-text-muted border-gray-200 hover:border-green-800/30"
                  }`}>
                  <Filter size={16} /> Filters{" "}
                  {activeFilterCount > 0 && (
                    <span className="w-5 h-5 rounded-full bg-gold text-green-900 text-[11px] font-bold flex items-center justify-center">
                      {activeFilterCount}
                    </span>
                  )}
                </button>
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="flex items-center gap-2 px-4 py-3 rounded-xl border border-red-200 text-red-500 hover:bg-red-50 transition-all text-[14px] font-medium">
                    <FilterX size={16} /> Clear
                  </button>
                )}
                <select
                  value={sortField}
                  onChange={(e) => setSortField(e.target.value as typeof sortField)}
                  className="px-3 py-3 rounded-xl border border-gray-200 text-[13px] text-text-muted">
                  <option value="rating">Sort by Rating</option>
                  <option value="name">Sort by Name</option>
                  <option value="students">Sort by Students</option>
                  <option value="sessions">Sort by Sessions</option>
                  <option value="earnings">Sort by Earnings</option>
                  <option value="experience">Sort by Experience</option>
                  <option value="hourlyRate">Sort by Rate</option>
                </select>
              </div>
            </div>

            {showFilters && (
              <div
                className="mt-4 pt-4 border-t grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4"
                style={{ borderColor: "rgba(30,80,50,0.08)" }}>
                <FilterSelect
                  label="Status"
                  value={filters.status}
                  onChange={(v) => setFilters((p) => ({ ...p, status: v as TutorStatus }))}
                  options={[
                    { value: "", label: "All Status" },
                    ...Object.entries(STATUS_CONFIG).map(([k, v]) => ({
                      value: k,
                      label: v.label,
                    })),
                  ]}
                />
                <FilterSelect
                  label="Verification"
                  value={filters.verification}
                  onChange={(v) =>
                    setFilters((p) => ({ ...p, verification: v as VerificationLevel }))
                  }
                  options={[
                    { value: "", label: "All" },
                    ...Object.entries(VERIFICATION_CONFIG).map(([k, v]) => ({
                      value: k,
                      label: v.label,
                    })),
                  ]}
                />
                <FilterSelect
                  label="State"
                  value={filters.state}
                  onChange={(v) => setFilters((p) => ({ ...p, state: v }))}
                  options={[
                    { value: "", label: "All States" },
                    ...NIGERIAN_STATES.map((s) => ({ value: s, label: s })),
                  ]}
                />
                <FilterSelect
                  label="Teaching Mode"
                  value={filters.teachingMode}
                  onChange={(v) => setFilters((p) => ({ ...p, teachingMode: v as TeachingMode }))}
                  options={[
                    { value: "", label: "All" },
                    { value: "online", label: "Online" },
                    { value: "in_person", label: "In-Person" },
                    { value: "both", label: "Both" },
                  ]}
                />
                <div>
                  <label className="block text-[12px] font-semibold text-green-900 mb-2">
                    Hourly Rate
                  </label>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.minRate}
                      onChange={(e) => setFilters((p) => ({ ...p, minRate: e.target.value }))}
                      className="w-full px-2 py-2 rounded-lg border border-gray-200 text-[12px]"
                    />
                    <span className="text-text-muted text-[12px]">-</span>
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.maxRate}
                      onChange={(e) => setFilters((p) => ({ ...p, maxRate: e.target.value }))}
                      className="w-full px-2 py-2 rounded-lg border border-gray-200 text-[12px]"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Bulk Actions Bar */}
          {selectedTutors.size > 0 && (
            <div className="mb-4 p-4 rounded-2xl bg-green-800 text-white flex items-center justify-between">
              <span className="text-[14px] font-semibold">
                {selectedTutors.size} tutor{selectedTutors.size > 1 ? "s" : ""} selected
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleBulkAction("activate")}
                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[13px] font-medium flex items-center gap-1">
                  <Check size={14} /> Activate
                </button>
                <button
                  onClick={() => handleBulkAction("suspend")}
                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[13px] font-medium flex items-center gap-1">
                  <Ban size={14} /> Suspend
                </button>
                <button
                  onClick={() => handleBulkAction("verify")}
                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[13px] font-medium flex items-center gap-1">
                  <BadgeCheck size={14} /> Verify
                </button>
                <button
                  onClick={() => setSelectedTutors(new Set())}
                  className="ml-4 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[13px] font-medium flex items-center gap-1">
                  <X size={14} /> Clear
                </button>
              </div>
            </div>
          )}

          {/* Results Count */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-[13px] text-text-muted">
              Showing <span className="font-semibold text-green-900">{filteredTutors.length}</span>{" "}
              tutors
              {categoryFilter !== "all" && (
                <span className="ml-2">
                  in <span className="font-semibold text-green-900">{categoryFilter}</span>
                </span>
              )}
            </span>
          </div>

          {/* Grid View */}
          {viewMode === "grid" && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {paginatedTutors.map((tutor) => (
                <TutorCard
                  key={tutor.id}
                  tutor={tutor}
                  isSelected={selectedTutors.has(tutor.id)}
                  onSelect={() => handleSelectTutor(tutor.id)}
                />
              ))}
            </div>
          )}

          {/* List View */}
          {viewMode === "list" && (
            <div className="space-y-3">
              {paginatedTutors.map((tutor) => (
                <TutorListItem
                  key={tutor.id}
                  tutor={tutor}
                  isSelected={selectedTutors.has(tutor.id)}
                  onSelect={() => handleSelectTutor(tutor.id)}
                />
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6">
              <button
                onClick={() => setCurrentPage(1)}
                disabled={currentPage === 1}
                className="px-3 py-1.5 rounded-lg border border-gray-200 text-[13px] disabled:opacity-50">
                First
              </button>
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 rounded-lg border border-gray-200 text-[13px] disabled:opacity-50">
                Prev
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const page = i + Math.max(1, Math.min(currentPage - 2, totalPages - 4));
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-9 h-9 rounded-lg text-[13px] font-medium ${page === currentPage ? "bg-green-800 text-white" : "border border-gray-200"}`}>
                    {page}
                  </button>
                );
              })}
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 rounded-lg border border-gray-200 text-[13px] disabled:opacity-50">
                Next
              </button>
              <button
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 rounded-lg border border-gray-200 text-[13px] disabled:opacity-50">
                Last
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ─── TUTOR CARD ────────────────────────────────────────────
function TutorCard({
  tutor,
  isSelected,
  onSelect,
}: {
  tutor: Tutor;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const statusConfig = STATUS_CONFIG[tutor.status];
  const verifConfig = VERIFICATION_CONFIG[tutor.verificationLevel];
  const catConfig = CATEGORY_CONFIG[tutor.category];
  const VerifIcon = verifConfig.icon;
  const CatIcon = catConfig.icon;

  return (
    <div
      className={`p-5 rounded-2xl bg-white border transition-all hover:-translate-y-1 hover:shadow-lg group relative ${
        isSelected ? "ring-2 ring-green-800 shadow-lg" : ""
      }`}
      style={{ borderColor: "rgba(30,80,50,0.08)" }}>
      {/* Selection Checkbox */}
      <div className="absolute top-3 left-3 z-10">
        <input
          type="checkbox"
          checked={isSelected}
          onChange={onSelect}
          onClick={(e) => e.stopPropagation()}
          className="w-4 h-4 rounded border-gray-300 text-green-800 focus:ring-green-500"
        />
      </div>

      {/* Avatar & Status */}
      <div className="flex items-start justify-between mb-3 mt-2">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-14 h-14 rounded-full bg-cream flex items-center justify-center overflow-hidden">
              {tutor.avatar ? (
                <img src={tutor.avatar} alt="" className="w-full h-full object-cover" />
              ) : (
                <Users size={28} className="text-green-800" />
              )}
            </div>
            {tutor.isOnline && (
              <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-green-500 border-2 border-white" />
            )}
            <div
              className="absolute -top-1 -left-1 w-5 h-5 rounded-full flex items-center justify-center"
              style={{ background: catConfig.bg }}>
              <CatIcon size={10} style={{ color: catConfig.color }} />
            </div>
          </div>
          <div>
            <h3 className="text-[14px] font-semibold text-green-900 line-clamp-1">{tutor.name}</h3>
            <p className="text-[11px] text-text-muted line-clamp-1">{tutor.title}</p>
          </div>
        </div>
        <div className="flex flex-col gap-1 items-end">
          <span
            className="px-2 py-0.5 rounded-full text-[9px] font-semibold"
            style={{ background: statusConfig.bg, color: statusConfig.text }}>
            {statusConfig.label}
          </span>
          <span className="flex items-center gap-1 text-[9px]" style={{ color: verifConfig.text }}>
            <VerifIcon size={9} /> {verifConfig.label}
          </span>
        </div>
      </div>

      {/* Specializations */}
      <div className="flex flex-wrap gap-1 mb-3">
        {tutor.specialization.slice(0, 3).map((spec) => {
          const specConfig = SPECIALIZATIONS[spec];
          return (
            <span
              key={spec}
              className="px-2 py-0.5 rounded-full text-[9px] font-medium"
              style={{ background: specConfig?.bg, color: specConfig?.color }}>
              {specConfig?.label || spec}
            </span>
          );
        })}
        {tutor.specialization.length > 3 && (
          <span className="px-2 py-0.5 rounded-full text-[9px] text-text-muted bg-gray-100">
            +{tutor.specialization.length - 3}
          </span>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        <div className="p-2 rounded-lg bg-cream/50 text-center">
          <div className="flex items-center justify-center gap-1 text-[12px] font-bold text-green-900">
            <Star size={10} className="text-gold fill-gold" /> {tutor.rating.toFixed(1)}
          </div>
          <div className="text-[9px] text-text-muted">{tutor.reviewCount} reviews</div>
        </div>
        <div className="p-2 rounded-lg bg-cream/50 text-center">
          <div className="text-[12px] font-bold text-green-900">{tutor.totalStudents}</div>
          <div className="text-[9px] text-text-muted">students</div>
        </div>
        <div className="p-2 rounded-lg bg-cream/50 text-center">
          <div className="text-[12px] font-bold text-green-900">{tutor.totalSessions}</div>
          <div className="text-[9px] text-text-muted">sessions</div>
        </div>
        <div className="p-2 rounded-lg bg-cream/50 text-center">
          <div className="text-[12px] font-bold text-green-900">
            ₦{(tutor.hourlyRate / 1000).toFixed(0)}K
          </div>
          <div className="text-[9px] text-text-muted">/hour</div>
        </div>
      </div>

      {/* Location & Experience */}
      <div className="flex items-center justify-between text-[10px] text-text-muted mb-3">
        <span className="flex items-center gap-1">
          <MapPin size={10} /> {tutor.city}, {tutor.state}
        </span>
        <span>{tutor.experience} yrs</span>
      </div>

      {/* Action Button */}
      <Link
        href={`/admin/tutors/${tutor.id}`}
        className="block w-full py-2 rounded-lg bg-green-800 text-white text-[12px] font-semibold text-center hover:bg-green-700 transition-all">
        View Profile
      </Link>
    </div>
  );
}

// ─── TUTOR LIST ITEM ───────────────────────────────────────
function TutorListItem({
  tutor,
  isSelected,
  onSelect,
}: {
  tutor: Tutor;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const statusConfig = STATUS_CONFIG[tutor.status];
  const verifConfig = VERIFICATION_CONFIG[tutor.verificationLevel];
  const catConfig = CATEGORY_CONFIG[tutor.category];
  const VerifIcon = verifConfig.icon;
  const CatIcon = catConfig.icon;

  return (
    <div
      className={`p-4 rounded-2xl bg-white border flex items-center gap-4 hover:bg-cream/30 transition-colors group ${
        isSelected ? "ring-2 ring-green-800 bg-green-50" : ""
      }`}
      style={{ borderColor: "rgba(30,80,50,0.08)" }}>
      <input
        type="checkbox"
        checked={isSelected}
        onChange={onSelect}
        className="w-4 h-4 rounded border-gray-300 text-green-800 focus:ring-green-500 shrink-0"
      />

      <div className="relative shrink-0">
        <div className="w-12 h-12 rounded-full bg-cream flex items-center justify-center overflow-hidden">
          {tutor.avatar ? (
            <img src={tutor.avatar} alt="" className="w-full h-full object-cover" />
          ) : (
            <Users size={22} className="text-green-800" />
          )}
        </div>
        {tutor.isOnline && (
          <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-green-500 border-2 border-white" />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="text-[14px] font-semibold text-green-900">{tutor.name}</h3>
          <span
            className="px-1.5 py-0.5 rounded-full text-[9px] font-semibold flex items-center gap-0.5"
            style={{ background: catConfig.bg, color: catConfig.color }}>
            <CatIcon size={8} /> {catConfig.label}
          </span>
          <span
            className="px-1.5 py-0.5 rounded-full text-[9px] font-semibold"
            style={{ background: statusConfig.bg, color: statusConfig.text }}>
            {statusConfig.label}
          </span>
          <span
            className="flex items-center gap-0.5 text-[9px]"
            style={{ color: verifConfig.text }}>
            <VerifIcon size={9} /> {verifConfig.label}
          </span>
          {tutor.isFeatured && (
            <span className="px-1.5 py-0.5 rounded-full text-[9px] font-semibold bg-purple-100 text-purple-600">
              <Crown size={9} /> Featured
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 text-[11px] text-text-muted">
          <span>{tutor.title}</span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Star size={10} className="text-gold fill-gold" /> {tutor.rating.toFixed(1)} (
            {tutor.reviewCount})
          </span>
          <span>•</span>
          <span>{tutor.totalStudents} students</span>
          <span>•</span>
          <span>{tutor.totalSessions} sessions</span>
        </div>

        <div className="flex flex-wrap gap-1 mt-2">
          {tutor.specialization.slice(0, 4).map((spec) => {
            const specConfig = SPECIALIZATIONS[spec];
            return (
              <span
                key={spec}
                className="px-1.5 py-0.5 rounded-full text-[8px] font-medium"
                style={{ background: specConfig?.bg, color: specConfig?.color }}>
                {specConfig?.label || spec}
              </span>
            );
          })}
        </div>
      </div>

      <div className="text-right shrink-0">
        <div className="text-[14px] font-bold text-green-900">
          ₦{tutor.hourlyRate.toLocaleString()}
          <span className="text-[11px] text-text-muted font-normal">/hr</span>
        </div>
        <div className="text-[10px] text-text-muted">
          ₦{tutor.earningsThisMonth.toLocaleString()} this mo
        </div>
      </div>

      <Link
        href={`/admin/tutors/${tutor.id}`}
        className="p-2 rounded-lg hover:bg-green-50 transition-colors shrink-0">
        <Eye size={16} className="text-text-muted group-hover:text-green-600" />
      </Link>
    </div>
  );
}

// ─── HELPER COMPONENTS ─────────────────────────────────────
function MiniCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: any;
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <div
      className="p-3 rounded-2xl bg-white border transition-all hover:-translate-y-1"
      style={{ borderColor: "rgba(30,80,50,0.08)" }}>
      <div
        className="w-8 h-8 rounded-lg flex items-center justify-center mb-2"
        style={{ background: `${color}15` }}>
        <Icon size={14} style={{ color }} />
      </div>
      <div className="text-lg font-bold text-green-900">{value}</div>
      <div className="text-[11px] text-text-muted">{label}</div>
    </div>
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div>
      <label className="block text-[12px] font-semibold text-green-900 mb-2">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 rounded-lg border border-gray-200 text-[13px] focus:outline-none focus:ring-2 focus:ring-green-500/30">
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

// Missing icon
const PauseCircle = ({ size, className }: any) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={2}
    className={className}>
    <circle cx="12" cy="12" r="10" />
    <line x1="10" y1="15" x2="10" y2="9" />
    <line x1="14" y1="15" x2="14" y2="9" />
  </svg>
);
